import {
    Connection,
    Keypair,
    PublicKey,
    Transaction,
    SystemProgram,
} from "@solana/web3.js";
import { Market } from "@project-serum/serum";
import * as dotenv from "dotenv";
import bs58 from 'bs58'; // Για τη μετατροπή Base58 σε Uint8Array

dotenv.config();

const connection = new Connection(
    "https://api.mainnet-beta.solana.com",
    "confirmed",
);
let wallet;

// Δημιουργία ή φόρτωση πορτοφολιού
if (process.env.PRIVATE_KEY) {
    try {
        // Διαβάζουμε το ιδιωτικό κλειδί από το .env σε μορφή Base58
        const privateKeyBase58 = process.env.PRIVATE_KEY;

        // Μετατροπή Base58 σε Uint8Array
        const privateKey = bs58.decode(privateKeyBase58);

        // Έλεγχος αν το ιδιωτικό κλειδί έχει ακριβώς 64 bytes
        if (privateKey.length !== 64) {
            throw new Error("Το ιδιωτικό κλειδί πρέπει να έχει ακριβώς 64 bytes.");
        }

        wallet = Keypair.fromSecretKey(privateKey);
        console.log(
            "Wallet Address from PRIVATE_KEY:",
            wallet.publicKey.toBase58(),
        );
    } catch (error) {
        console.error("Σφάλμα φόρτωσης πορτοφολιού:", error);
        process.exit(1);
    }
} else {
    // Αν δεν υπάρχει ιδιωτικό κλειδί στο .env, δημιουργούμε νέο
    wallet = Keypair.generate();
    console.log("New Wallet Address:", wallet.publicKey.toBase58());
}

// Συνάρτηση για φόρτωση αγοράς Serum
async function loadMarket(marketAddress) {
    try {
        console.log("Φορτώνω αγορά:", marketAddress);
        const marketPubkey = new PublicKey(marketAddress);
        const market = await Market.load(connection, marketPubkey, {}, "serum");
        console.log(`Market ${marketAddress} loaded successfully.`);
        return market;
    } catch (error) {
        console.error("Σφάλμα φόρτωσης αγοράς:", error);
        throw error; // Επιστρέφει το σφάλμα για debugging
    }
}

// Συνάρτηση για εκτέλεση trade
async function trade(market, side, price, size) {
    try {
        const payer = wallet.publicKey;
        const transaction = await market.makePlaceOrderTransaction(connection, {
            owner: payer,
            payer: market.quoteWallet,
            side, // 'buy' ή 'sell'
            price,
            size,
            orderType: "limit", // Χρήση limit order
        });
        await connection.sendTransaction(transaction, [wallet], {
            skipPreflight: false,
            preflightCommitment: "confirmed",
        });
        console.log(
            `Εκτελέστηκε trade ${side} για ${size} tokens στην τιμή ${price}`,
        );
    } catch (error) {
        console.error("Σφάλμα κατά την εκτέλεση trade:", error);
    }
}

// Συνάρτηση για αποστολή SOL
async function sendSol(recipientAddress, amount) {
    try {
        const transaction = new Transaction().add(
            SystemProgram.transfer({
                fromPubkey: wallet.publicKey,
                toPubkey: new PublicKey(recipientAddress),
                lamports: amount * 1e9,
            }),
        );

        const signature = await connection.sendTransaction(
            transaction,
            [wallet],
            {
                skipPreflight: false,
                preflightCommitment: "confirmed",
            },
        );
        console.log(
            `Withdrawal επιτυχής! Transaction ID: https://explorer.solana.com/tx/${signature}`,
        );
    } catch (error) {
        console.error("Σφάλμα κατά την αποστολή withdrawal:", error);
    }
}

// Αυτόματη αποστολή SOL κατά τον τερματισμό
process.on("SIGINT", async () => {
    console.log("\nΤερματισμός προγράμματος... Ξεκινά αυτόματο withdrawal.");
    const recipientAddress = wallet.publicKey.toBase58(); // Διεύθυνση του πορτοφολιού του bot
    const amount = 0.0001; // Το ποσό που θέλεις να στείλεις

    await sendSol(recipientAddress, amount); // Αποστολή SOL στο πορτοφόλι του bot
    console.log("Withdraw ολοκληρώθηκε. Κλείσιμο...");
    process.exit(0);
});

// Κύρια λειτουργία bot
async function runBot() {
    console.log("Ξεκίνησε το bot...");
    const marketAddress = "6eHXmiuWfVPzceNvBd6S7aQj34WppMfvPrZrSh8Cr2rL"; // Διεύθυνση για SOL/USDT
    let market;
    try {
        market = await loadMarket(marketAddress);
    } catch (error) {
        console.error("Αποτυχία φόρτωσης αγοράς. Έλεγχος διεύθυνσης...");
        process.exit(1);
    }

    while (true) {
        console.log("Εκτελείται trading...");
        await trade(market, "buy", 0.0001, 1); // Παράδειγμα trade αγοράς
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Παύση 5 δευτερολέπτων
    }
}

runBot().catch(console.error);